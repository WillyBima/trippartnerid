<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">

    <!-- title -->
    <title>Daftar</title>
    <!-- end title -->
    <?php echo $__env->make('master.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('head-frontend'); ?>
  </head>

  <body style="height: 100%; background: #ecf0f1; font-family: Cambria;">
    <!-- Content -->
    <section id="login">
      <div class="container-fluid" style="margin-top: 55px;">
        <p class="title text-center" style="font-family: Cambria; font-size: 24px; color: #25aae2; margin-bottom: 20px;">Daftar Sebagai Admin </p>
        <div class="row">
          <div class="col-md-2">

          </div>
          <div class="col-md-8" style="text-align: -webkit-center;">
            <div class="card" style="width: 500px">
              <form class="login" style="padding: 50px;">
                <div class="form-group">
                  <input type="text" class="form-control" name="nama_lengkap" placeholder="Nama Lengkap">
                </div>

                <div class="form-group">
                  <input type="email" class="form-control" name="email" placeholder="Alamat Email">
                </div>

                <div class="form-group">
                  <input type="password" class="form-control" name="password" placeholder="Kata Sandi">
                </div>

                <p class="privacy-policy-txt" style="font-size: 14px; margin-top: 30px; margin-bottom: 30px;">
				          Dengan mengklik button “Daftar” di bawah ini, saya setuju dengan <a href='privacy-policy' style="color: #f96d01;">Kebijakan Privasi
                  </a> serta <a href='tos' style="color: #f96d01;">Syarat dan Ketentuan</a> TripPartner.com			</p>

                <a href="#" class="btn btn-block" role="button" style="background-color: #f96d01; color: #ffffff;">Daftar</a>

                <p class="dont-have-account js-href" style="margin-top: 20px;">
            			Sudah punya akun?  <a href="/loginAdmin" data-state="register" style="color: #f96d01; font-size: 15px;">Login Sekarang</a>
            		</p>
              </form>
            </div>
          </div>
          <div class="col-md-2">

          </div>
        </div>
      </div>
    </section>
  </body>
</html>
<?php /**PATH C:\xampp\htdocs\trippartnercom\resources\views/backend/register/daftarAdmin.blade.php ENDPATH**/ ?>