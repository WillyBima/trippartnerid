<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <!-- title -->
    <title>Booking Online</title>
    <!-- end title -->
    <?php echo $__env->make('master.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('head-frontend'); ?>
  </head>

  <body style="height: 100%;">
    <!-- logo atas -->
    <?php echo $__env->make('master.body', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('header-frontend'); ?>
    <!-- end logo -->

    <!-- Navbar -->
    <?php echo $__env->yieldContent('navbar-frontend'); ?>
    <!-- End Navbar -->

    <!-- Header Title -->
        <section id="header">
            <div class="container-fluid" style="background-image: url(<?php echo e(url('assets/img/header.jpg')); ?>);
            margin-bottom: 40px;
            background-size: cover;
            height: auto;
            padding: 25px;">
                <p class="title-header"><b>BOOKING ONLINE</b></p>
                <p class="subtitle-header"> Beranda > Booking Online</p>
            </div>
        </section>

        <!-- booking now -->
        <section id="booking">
            <div class="container-fluid" style="background-image: url(<?php echo e(url('assets/img/searching.png')); ?>); background-size: cover;padding: 20px; font-family: Cambria; margin-bottom: 50px">
              <form action="<?php echo e(url('/cari-bus')); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                <div class="row">
                  <div class="col-md-12">
                    <div class="row">
                      <div class="col-md-6">

                      </div>
                      <div class="col-md-6">

                      </div>
                    </div>

                    <div class="row">
                      <div class="col-md-4"></div>
                      <div class="col-md-4 text-center">
                        <div class="form-group">
                          <label>Rute Perjalanan</label>
                          <select class="form-control" name="kota_asal">
                            <?php $__currentLoopData = $rute; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kota_asal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($kota_asal->nama_kota); ?>"><?php echo e($kota_asal->nama_kota); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select><br>
                          <select class="form-control" name="kota_tujuan">
                            <?php $__currentLoopData = $rute; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kota_tujuan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($kota_tujuan->nama_kota); ?>"><?php echo e($kota_tujuan->nama_kota); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                        </div>
                        <div class="form-group">
                          <select name="jenis_bus" class="form-control">
                            <option value="">Pilih Jenis Bus yang di inginkan</option>
                            <option value="Small Bus">Small Bus</option>
                            <option value="Medium Bus">Medium Bus</option>
                            <option value="Big Bus">Big Bus</option>
                          </select>
                        </div>
                        <div class="form-group">
                            <input type="text" name="harga" class="form-control" placeholder="Harga Bus yang di inginkan">
                        </div>
                        <div class="form-group">
                          <select name="fasilitas" class="form-control">
                            <option value="">Pilih Fasilitas</option>
                            <option value="1">Fasilitas kelas 1</option>
                            <option value="2">Fasilitas kelas 2</option>
                            <option value="3">Fasilitas kelas 3</option>
                          </select>
                        </div>
                        <button class="btn btn-lg" role="button" style="font-family: Cambria; background-color: #f96d01; color: #ffffff; margin-top: 30px;"><span class="fa fa-search color-white"></span> Cari Sekarang</button>
                      </div>
                      <div class="col-md-4"></div>
                    </div>
                  </div>
                </div>
              </form>
                <div class="row" style="margin-top: 50px; margin-bottom: 30px;">
                  <div class="col-md-2">

                  </div>
                  <div class="col-md-8 text-center">
                    <div class="alert alert-warning">
                      <a style="font-size: 15px; font-family: Cambria; color: #25aae2;">Harap pastikan perjalanan Anda terselesaikan pada periode yang dipilih</a>
                      <!-- <p class="" style="font-size: 10px; font-family: Century Gothic; color: #25aae2;">Harap pastikan perjalanan Anda terselesaikan pada periode yang dipilih </p> -->
                    </div>
                  </div>
                  <div class="col-md-2">

                  </div>
                </div>
            </div>
        </section>

    <!-- FOOTER -->
    <?php echo $__env->yieldContent('footer-frontend'); ?>
    <!-- end Footer -->

    <!-- script -->
    <?php echo $__env->yieldContent('script-frontend'); ?>
    <!-- endscript -->
  </body>
</html>
<?php /**PATH C:\xampp\htdocs\trippartnercom\resources\views/frontend/booking/booking-online.blade.php ENDPATH**/ ?>