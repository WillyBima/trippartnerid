<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">

    <!-- title -->
    <title>Detail Armada</title>
    <!-- end title -->
    <?php echo $__env->make('master.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('head-frontend'); ?>
  </head>

  <body style="height: 100%;">
    <!-- logo atas -->
    <?php echo $__env->make('master.body', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('header-frontend'); ?>
    <!-- end logo -->

    <!-- Navbar -->
    <?php echo $__env->yieldContent('navbar-frontend'); ?>
    <!-- End Navbar -->

    <!-- Header -->
        <section id="header">
            <div class="container-fluid" style="background-image: url(<?php echo e(url('assets/img/header.jpg')); ?>);
            margin-bottom: 40px;
            background-size: cover;
            height: auto;
            padding: 25px;">
                <p class="title-header"><b>ARMADA</b></p>
                <p class="subtitle-header"> Beranda > Armada > PO. HIBA UTAMA </p>
            </div>
        </section>

    <section>
      <div class="container-fluid">
        <?php $__currentLoopData = $datapo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dpo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <p class="title-po text-center" style="text-transform: uppercase;"><b>PO <?php echo e($dpo->nama_po); ?></b></p>
            <div class="row">
              <div class="col-md-12">
                <p class="title-armada text-center" style="margin-left: 0px;"><b>Big Bus <?php echo e($dpo->nama_po); ?></b></p>
                <hr style="width: 1000px; border-bottom: 1px solid #f96d01;">
              </div>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <!-- big bus -->
            <div class="row text-center" style="padding: 30px;">
              <?php $__currentLoopData = $big_bus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="col-md-4">
                <div class="card" style="width:399px">
                  <img class="card-img-top" src="<?php echo e(url('img/bus/'.$bb->gambar_bus)); ?>" alt="Card image" style="width: 398px; height: 369px;">
                  <div class="card-body">
                    <p class="card-text"><?php echo e($bb->nama_bus); ?></p>
                    <a href="<?php echo e(url('/boking/booking-sekarang/'.$bb->slug)); ?>" class="btn btn-sm card-btn" role="button">Lihat Selengkapnya</a>
                  </div>
                </div>
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="row">
              <div class="col-md-12">
                <p class="title-armada text-center" style="margin-left: 0px;"><b>Medium Bus <?php echo e($dpo->nama_po); ?></b></p>
                <hr style="width: 1000px; border-bottom: 1px solid #f96d01;">
              </div>
            </div>
            <!-- Medium bus -->
            <div class="row text-center" style="padding: 30px;">
              <?php $__currentLoopData = $medium_bus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="col-md-4">
                <div class="card" style="width:399px">
                  <img class="card-img-top" src="<?php echo e(url('img/bus/'.$mb->gambar_bus)); ?>" alt="Card image" style="width: 398px; height: 369px;">
                  <div class="card-body">
                    <p class="card-text"><?php echo e($mb->nama_bus); ?></p>
                    <a href="<?php echo e(url('/boking/booking-sekarang/'.$mb->slug)); ?>" class="btn btn-sm card-btn" role="button">Lihat Selengkapnya</a>
                  </div>
                </div>
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="row">
              <div class="col-md-12">
                <p class="title-armada text-center" style="margin-left: 0px;"><b>Small Bus <?php echo e($dpo->nama_po); ?></b></p>
                <hr style="width: 1000px; border-bottom: 1px solid #f96d01;">
              </div>
            </div>
            <!-- big bus -->
            <div class="row text-center" style="padding: 30px;">
              <?php $__currentLoopData = $small_bus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="col-md-4">
                <div class="card" style="width:399px">
                  <img class="card-img-top" src="<?php echo e(url('img/bus/'.$sb->gambar_bus)); ?>" alt="Card image" style="width: 398px; height: 369px;">
                  <div class="card-body">
                    <p class="card-text"><?php echo e($sb->nama_bus); ?></p>
                    <a href="<?php echo e(url('/boking/booking-sekarang/'.$sb->slug)); ?>" class="btn btn-sm card-btn" role="button">Lihat Selengkapnya</a>
                  </div>
                </div>
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

      </div>
    </section>

    <!-- FOOTER -->
    <?php echo $__env->yieldContent('footer-frontend'); ?>
    <!-- end Footer -->

    <!-- script -->
    <?php echo $__env->yieldContent('script-frontend'); ?>
    <!-- endscript -->
  </body>
</html>
<?php /**PATH C:\xampp\htdocs\trippartnercom\resources\views/frontend/armada/detail-armada.blade.php ENDPATH**/ ?>