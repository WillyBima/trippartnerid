<!DOCTYPE html>
<html lang="en">
<head>
 <meta charset="UTF-8">
 <title>Email</title>
</head>
<body>
Hello  thanks for registering! <br><br>
<br><br> test email 

</a><br><br><br><br><br>
Cheers,<br><br>
<p style="color:red;">Team.</p>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\trippartnercom\resources\views/frontend/email/viewemail.blade.php ENDPATH**/ ?>