<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Supir extends Model
{
  protected $table = 'supir';

  protected $fillable =
  [
    'nama_supir',
  ];
}
